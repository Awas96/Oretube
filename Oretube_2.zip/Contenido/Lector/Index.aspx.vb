﻿
Partial Class Contenido_Editor_Index
    Inherits System.Web.UI.Page


End Class
