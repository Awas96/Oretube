﻿
Imports System.Data.SqlClient

Partial Class Contenido_Editor_Index
    Inherits System.Web.UI.Page

    Private Sub Contenido_Editor_Index_Load(sender As Object, e As EventArgs) Handles Me.Load
        FVEscribirComentario.ChangeMode(FormViewMode.Insert)
    End Sub

    Private Sub FVEscribirComentario_ItemInserting(sender As Object, e As FormViewInsertEventArgs) Handles FVEscribirComentario.ItemInserting
        Dim urlVideo = Request.QueryString("vid")
        SQLDSEscribirComentaro.InsertParameters.Item("fecha").DefaultValue = Date.Now
        SQLDSEscribirComentaro.InsertParameters.Item("usuario").DefaultValue = Session("dUsuario").Rows.Item(0).Item(0)
        SQLDSEscribirComentaro.InsertParameters.Item("video").DefaultValue = buscaVideo(urlVideo)
    End Sub

    Private Sub FVEscribirComentario_ItemInserted(sender As Object, e As FormViewInsertedEventArgs) Handles FVEscribirComentario.ItemInserted
        Response.Redirect(HttpContext.Current.Request.Url.ToString(), True)
    End Sub



    Private Function buscaVideo(ByVal url As String) As Integer
        Dim respuesta As Integer = 0
        Dim cnx As New SqlConnection With {
           .ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("oretubeConnectionString").ConnectionString
    }
        Dim sentencia As String = "select id from video where [url] =  @url"
        Dim cmd As New SqlCommand(sentencia, cnx)
        cmd.Parameters.AddWithValue("@url", url)

        Try
            cnx.Open()
            Dim resultado As String = cmd.ExecuteScalar()
            If resultado <> Nothing Then respuesta = resultado

        Catch ex As Exception

        Finally
            cnx.Close()
        End Try
        Return respuesta
    End Function


    'Protected Sub imgBtNoLikes_Click()
    '    Response.Write("Has pulsado el boton")
    '    Dim idUsuario As Int32 = Session("dUsuario").Rows.Item(0).Item(0).ToString
    '    Dim urlVideo = Request.QueryString("vid")
    '    Dim idVideo As String = buscaVideo(urlVideo)
    '    Dim voto As Integer = 0

    '    Select Case 
    '        Case "Likes"
    '            voto = 1
    '        Case "NoLikes"
    '            voto = 0
    '    End Select
    '    Response.Write(e.CommandArgument.ToString)
    '    SQLDSVotar.UpdateParameters.Item("votacion").DefaultValue = voto
    '    SQLDSVotar.UpdateParameters.Item("votante").DefaultValue = idUsuario
    '    SQLDSVotar.UpdateParameters.Item("elVideo").DefaultValue = idVideo
    '    SQLDSVotar.Update()
    'End Sub
End Class
